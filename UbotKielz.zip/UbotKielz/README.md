
```
apt update && apt upgrade -y
```
```
git clone https://github.com/AlwaysBoyszz/Ubotpremboy
```
```
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
```
```
cd yass && screen -S yass
```
```
bash installnode.sh && apt install python3-venv
```
```
python3 -m venv yass && source yass/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m fansx
```
