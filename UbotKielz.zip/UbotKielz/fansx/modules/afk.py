__MODULE__ = "ᴀꜰᴋ"
__HELP__ = """
<blockquote><b>「Bantuan untuk Afk」

⪩ Perintah : <code>{0}afk</code> [alasan]
    ↝ untuk mengaktifkan afk

⪩ Perintah : <code>{0}unafk</code>
    ↝ menonaktifkan afk</b></blockquote>
"""
